This spec aims to enhance Gradle's model of Eclipse projects, so users can customize every aspect of their Eclipse projects in their build.

## Features

- [Resource Filters](resource-filters)
- [Preference Files](preference-files)
