## Automatically enable dependency substitution for homogeneous composites

### Overview

### API

### Implementation notes

### Test Coverage

### Documentation

### Open issues

