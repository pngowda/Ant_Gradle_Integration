package org.b2;

import org.c.Something;

public interface Different {
    Something returnSomething();
}
