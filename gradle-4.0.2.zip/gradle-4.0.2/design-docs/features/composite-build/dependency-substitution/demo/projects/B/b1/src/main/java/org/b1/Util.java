package org.b1;

public class Util {
   public static int getAnswer() { return 42; }
}

