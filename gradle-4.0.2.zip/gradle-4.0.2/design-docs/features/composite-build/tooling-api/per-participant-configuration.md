## Tooling client can specify arguments that apply to one participant in a composite

### Overview

This allows a user to specify arguments/configuration that apply to only one participant in a composite.

### API

- TBD

### Implementation notes

- Need to consider how this mixes with "composite wide" arguments

### Test coverage

- TBD

### Out of Scope

- TBD
